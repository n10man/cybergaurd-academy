<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Modern_Office_MV_1_TILESETS_B-C-D-E" tilewidth="16" tileheight="16" tilecount="2304" columns="48">
 <image source="../../../../../../maps/Modern_Office_Revamped_v1.2/5_Modern_Office_RPG_MAKER_MV/Modern_Office_MV_1_TILESETS_B-C-D-E.png" width="768" height="768"/>
</tileset>
