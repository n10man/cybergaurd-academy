<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Modern_Office_Black_Shadow" tilewidth="16" tileheight="16" tilecount="848" columns="16">
 <image source="../../../../../../maps/Modern_Office_Revamped_v1.2/2_Modern_Office_Black_Shadow/Modern_Office_Black_Shadow.png" width="256" height="848"/>
</tileset>
